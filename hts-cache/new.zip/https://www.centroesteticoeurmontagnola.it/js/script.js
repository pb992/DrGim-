<!doctype html><html lang="it"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="X-UA-Compatible" content="ie=edge"><title>Centro estetico Eur Montagnola Roma | Centro estetico Dr Gimò</title><meta name="robots" content="noindex, nofollow"><meta name="facebook-domain-verification" content=""/><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{
    "@type": "HealthAndBeautyBusiness",
    "name": "Centro estetico Dr Gimò",
    "@id": "https://centroesteticoeurmontagnola.it/#school",
    "image": "https://centroesteticoeurmontagnola.it/images/images/logo_drgimo.png",
    "telephone": [
        "+39 06 5406882"
    ],
    "email": "info@centroesteticoeurmontagnola.it",
    "address": {
        "@type": "PostalAddress",
        "streetAddress": "Via Benedetto Croce, 91",
        "addressLocality": "Roma",
        "addressRegion": "RM",
        "addressCountry": "IT",
        "postalCode": "00142"
    },
    "description": "Centro estetico Roma Eur, massaggi Roma Eur, manicure e pedicure Roma Eur",
    "url": "https://centroesteticoeurmontagnola.it/",
    "sameAs": [
            "https://www.facebook.com/Centro-Estetico-Dr-Gim%C3%B2-428439843927852/",
            "https://instagram.com/centroesteticodrgimo"
        ],
    "geo": {
        "@type": "GeoCoordinates",
        "latitude": 41.87937929722342,
        "longitude": 12.520984229248741
    },
    "hasMap": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d742.6566532885165!2d12.520984229248741!3d41.87937929722342!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f6175e6be46f9%3A0xd2744afb30bb1c40!2sVelvet%20Centro%20Estetico%20e%20Tattoo%20-%20San%20Giovanni%20-%20Tuscolana%20-%20Appia!5e0!3m2!1sit!2sit!4v1602766448776!5m2!1sit!2sit",
    "openingHoursSpecification": [
        {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday"
            ],
            "opens": "9:30",
            "closes": "19:30"
        },
        {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Saturday"
            ],
            "opens": "9:30",
            "closes": "12:30"
        }
    ],
    "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.6",
        "reviewCount": "42"
    }
    },{
        "@type":"WebSite",
        "@id":"https://centroesteticoeurmontagnola.it/#website",
        "url":"https://centroesteticoeurmontagnola.it/",
        "name":"Centro estetico Dr Gimò",
        "description":"centro estetico Roma Eur, massaggi Roma Eur, manicure e pedicure Roma Eur","inLanguage":"it-IT"
        },{
            "@type":"ImageObject",
            "@id":"https://centroesteticoeurmontagnola.it/#primaryimage",
            "inLanguage":"it-IT",
            "url":"https://centroesteticoeurmontagnola.it/images/logo_drgimo.png","width":720,"height":480,
            "caption":"centro estetico Roma Eur, massaggi Roma Eur, manicure e pedicure Roma Eur"
        },{
            "@type":"WebPage",
            "@id":"https://centroesteticoeurmontagnola.it/#webpage",
            "url":"https://centroesteticoeurmontagnola.it",
            "name":" - Centro estetico Dr Gimò",
            "isPartOf":{"@id":"https://centroesteticoeurmontagnola.it/#website"},
            "primaryImageOfPage":{"@id":"https://centroesteticoeurmontagnola.it/#primaryimage"},
            "datePublished":"2022-02-10T10:26:17+00:00","dateModified":"2022-02-10T11:10:31+00:00",
            "description":".","inLanguage":"it-IT","potentialAction":[{"@type":"ReadAction","target":["https://centroesteticoeurmontagnola.it/"]}]
        }
    ]}</script><link type="image/png" href="/images/favicon.png" rel="shortcut icon"/><!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]--><script defer data-domain="centroesteticoeurmontagnola.it" src="/js/script.js"></script><script defer="defer" src="/scripts/jquery.js?9adba79dc0e60905bce7"></script><script defer="defer" src="/scripts/main.js?9adba79dc0e60905bce7"></script><script defer="defer" src="/scripts/theme.js?9adba79dc0e60905bce7"></script><link href="/styles/styles.css?9adba79dc0e60905bce7" rel="stylesheet"><link href="/styles/main.css?9adba79dc0e60905bce7" rel="stylesheet"></head><body><!-- Header section  -->
<header class="header_01 isSticky z-max pt-0">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-around bg-main text-body">
            <div class="space-x-4">
                <a class="text-white" target="_blank" href="https://www.facebook.com/Centro-Estetico-Dr-Gim%C3%B2-428439843927852/"><i class="icofont-facebook bg-main p-3 rounded-circle"></i></a>
                <a class="text-white" target="_blank" href="https://instagram.com/centroesteticodrgimo"><i class="icofont-instagram bg-main p-3 rounded-circle"></i></a>
            </div>
            <div class="pr-5">
                <i class="icofont-phone mr-2"></i> 06 5406882
            </div>
        </div>
	<div class="row align-items-center">
            <div class="col-4 col-sm-3 col-lg-1 col-xl-2">
                <div class="logo">
                    <a href="/" aria-label="Centro Estetico Dr.Gimò Eur Montagnola">
                        <img src="/images/logo_drgimo.svg"
                             alt="Centro Estetico Dr.Gimò Eur Montagnola" title="Centro Estetico Dr.Gimò Eur Montagnola">
                    </a>
                </div>
            </div>
            <div class="col-10 col-lg-11 col-xl-10 menu-col">
                <a href="javascript:void(0)" class="menu_btn"><i class="icofont-navigation-menu"></i></a>
                <nav class="mainMenu">
                    <ul>

                        <li class="menu-item-has-children">
                            <a href="javascript:void(0);">Estetica</a>
                            <ul class="sub-menu">
                                <li><a href="/estetica/medicina-estetica">Medicina Estetica</a></li>
                                <li><a href="/estetica/tattoo-piercing">Tattoo</a></li>
                                <li><a href="/estetica/trucco-semipermamente">TPC Semipermanente</a></li>
                                <li><a href="/estetica/estetica-oncologica">Estetica Oncologica</a></li>
                                <li><a href="/estetica/epilazione-laser-diodo">Epilazione Laser Diodo</a></li>
                                <li><a href="/estetica/pigmentazione">Pigmentazione</a></li>
                                <li><a href="/estetica/riduzione-acne">Riduzione Acne</a></li>
                            </ul>
                        </li>
                        <li class="menu-item-has-children">
                            <a href="javascript:void(0);">Trattamenti</a>
                            <ul class="sub-menu">
                                <li><a href="/trattamenti/massaggi">Massaggi</a></li>
                                <li><a href="/trattamenti/manicure-pedicure">Manicure e Pedicure</a></li>
                                <li><a href="/trattamenti/ricostruzione-unghie">Nails</a></li>
                                <li><a href="/trattamenti/epilazione">Epilazione</a></li>
                                <li><a href="/trattamenti/trattamenti-viso">Trattamenti Viso</a></li>
                                <li><a href="/trattamenti/trattamenti-corpo">Trattamenti Corpo</a></li>
                                <li><a href="/trattamenti/extension">Extension</a></li>
                                <li><a href="/trattamenti/make-up">Make Up</a></li>
                                <li><a href="/trattamenti/benessere">Benessere</a></li>
                            </ul>
                        </li>

                        <li class="menu-item-has-children">
                            <a href="javascript:void(0);">Diet &amp; Fitness</a>
                            <ul class="sub-menu">
                                <li><a href="/diet-fitness/fitness-wellness">Fitness &amp; Wellness</a></li>
                                <li><a href="/diet-fitness/diet-e-wellness-coaching">Diet e Wellness Coaching</a></li>
                            </ul>
                        </li>
                        <li class="menu-item-has-children">
                            <a href="javascript:void(0);">Chi siamo</a>
                            <ul class="sub-menu">
                                <li><a href="/chi-siamo/dottoressa-monica-gizzi">Dott.ssa Monica Gizzi</a></li>
                                <li><a href="/chi-siamo/drgimo-montagnola">DrGimò</a></li>
                                <li><a href="/gallery">Gallery</a></li>
                            </ul>
                        </li>
                        <li><a href="/estetica/tattoo-piercing" class="">Tattoo</a></li>
                        <li><a href="/estetica/trucco-semipermamente" class="">TPC Semipermanente</a></li>
                        <li><a href="/promozioni" class="">Promozioni</a></li>
                        <li><a href="/contattaci" class="">Contatti</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header> <div class="container position-relative">
    <div class="row justify-content-between  spad">
        <div class="col-12 col-md-3 pl-5 mt-5">
            <p class="text-danger">Errore</p>
            <p class="display-1 font-weight-bold text-danger">404</p>
        </div>
        <div class="col-12 col-md-6 text-right text-body">
            <p class="display-3 font-weight-bolder">Oops..</p>
            <p class="h1 font-weight-light">Sembra che la risorsa non sia disponibile.</p>
            <p class="h3">Prova a ricaricare la pagina o ad <b>utilizzare il menù di navigazione</b></p>
            <p>Impossibile trovare la risorsa specificata</p>
        </div>
    </div>
    <img class="max-w-64 mt-5" src="/images/drgimo_art_centro_estetico.svg">
    

</div> <footer class="footer_01 fm_dark">
    <div class="layer_img">
        <img src="/images/footer.png" alt=""/>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-lg-4 col-xl-4">
                <aside class="widget about_widget">
                    <h3 class="widget_title">Chi siamo</h3>
                    <p>Prenditi uno spazio all'insegna del relax e prenota il tuo percorso benessere presso il Centro estetico Dr Gimò, a Roma in zona Eur Montagnola.</p>
                    <a href="/contatti" class="mo_btn mob_lg"><i class="icofont-long-arrow-right"></i>Contattaci</a>
                    <div class="text-small mt-4">
                        <span>Sede Legale: TERMA SRL - V. B. Croce 91 - ROMA (RM) - P.Iva: 05199371005</span>
                        <span>Camera Comm. Rm - REA 860718 - Cap. Soc. € 25.822,84 i.v</span>
                    </div>
                </aside>
            </div>
            <div class="col-md-4 col-lg-4 col-xl-4">
                <aside class="widget">
                    <h3 class="widget_title">Social</h3>
                    <p>
                        Seguici sui social
                    </p>
                    <aside class="widget">
                        <div class="nav-link mb-3">
                            <a class="text-white" target="_blank" href="https://www.facebook.com/Centro-Estetico-Dr-Gim%C3%B2-428439843927852/"><i class="icofont-facebook bg-main p-3 rounded-circle"></i> Centro estetico Dr Gimò Monica Gizzi</a>
                        </div>
                        <div class="nav-link mb-5">
                            <a class="text-white" target="_blank" href="https://instagram.com/centroesteticodrgimo"><i class="icofont-instagram bg-main p-3 rounded-circle"></i> Centro estetico Dr Gimò Monica Gizzi</a>
                        </div>
                    </aside>
                </aside>
            </div>
            <div class="col-md-4 col-lg-4 col-xl-3 offset-xl-1">
                <aside class="widget">
                    <h3 class="widget_title">Contatti</h3>
                    <div class="info_box">
                        <i class="icofont-location-pin"></i>
                        <p>Via Benedetto Croce, 91<br>00142 Roma (RM)</p>
                    </div>
                    <div class="info_box mb-5">
                        <i class="icofont-phone"></i>
                        <p>+39 06 5406882</p>
                    </div>
                    <div class="info_box">
                        <i class="icofont-clock-time"></i>
                        <p>Lunedì - Venerdì<br> 30 - 19:30<br>Sabato 9:30 -19:30</p>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</footer>
<section class="copyright copy_dark">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>© <span class="copyright-year">2024</span> TERMA SRL. Tutti i diritti riservati.</p>
            </div>
            <div class="col-md-6">
                <div class="copy_social">
                    <a target="_blank" href="https://www.facebook.com/Centro-Estetico-Dr-Gim%C3%B2-428439843927852/"><i class="icofont-facebook"></i></a>
                    <a target="_blank" href="https://instagram.com/centroesteticodrgimo"><i class="icofont-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
</section><div class="position-fixed wa-cta d-inline-block z-30"><a class="btn-callto d-flex align-items-center" href="https://wa.me/393488674330" target="_blank"><i class="icon icon-whatsapp"></i> <span class="d-none d-md-block">348 867 4330</span></a></div></body></html>